# Workday application — work history & certifications

Copy-paste source for the structured fields Workday asks you to fill in by
hand, separately from the résumé you upload.

---

## Should you fill in a description for all three jobs?

**Yes — fill all three.** It is worth the ten minutes, for one specific
reason: the résumé you upload and the work history you type are stored
separately. Recruiters search and filter on the **typed fields**, and plenty
of Workday tenants only index those. A blank description means the role is
invisible to that search even though your résumé describes it in detail.

Two things to keep in mind:

- **Keep each to 3–5 lines.** Nobody reads a wall of text in that box, and
  Workday's auto-parse often mangles long paste-ins. The versions below are
  already trimmed.
- **Don't contradict the résumé.** Same titles, same dates, same employers.
  Mismatches between the typed history and the attached PDF are a routine
  reason applications get flagged in screening.

If you are short on time, the priority order is **Akoncagua AI → ServiceNow
→ Neon IT Systems**. Recruiters read the most recent role first and often
stop there.

---

## 1. Akoncagua AI — AI Systems Engineer

| Field | Value |
|---|---|
| Job title | AI Systems Engineer |
| Company | Akoncagua AI |
| Location | Tampa, FL |
| From | December 2025 |
| To | Present ☑ I currently work here |

**Description**

```
Lead AI systems work on enterprise document-intelligence pipelines feeding
LLM pretraining, directing a team of 7 within a 15-person AI engineering org.
Own full fine-tuning strategy across CPT and SFT stages, including data
mixing, LoRA/PEFT adaptation, and benchmarking of open-source LLMs up to 32B
parameters against task-specific held-out sets. Optimized multi-GPU training
throughput using DeepSpeed ZeRO-3, gradient checkpointing, sequence
parallelism and mixed precision to cut compute cost. Architected a
multi-tier document classification pipeline that processed 2M+ enterprise
documents, routing 90%+ through low-cost tiers, and a distributed
GPU-accelerated conversion pipeline sustaining ~43,500 pages/hour.
```

---

## 2. ServiceNow — AI/ML Engineer

| Field | Value |
|---|---|
| Job title | AI/ML Engineer |
| Company | ServiceNow |
| Location | Texas, USA |
| From | July 2024 |
| To | November 2025 |

**Description**

```
Architected multi-step, state-based agent workflows with LangChain,
orchestrating conditional branching across ticket triage, classification and
tool-calling into ServiceNow APIs, improving self-service ticket resolution
by 35%. Built LLM-powered virtual agents handling IT and customer service
requests end to end, with human-in-the-loop escalation for high-risk cases.
Fine-tuned Transformer-based NLP models for intent classification and
knowledge base summarization. Established Responsible AI controls including
automated PII detection and redaction, and implemented ML observability with
MLflow, SageMaker Model Monitor and EvidentlyAI. Reduced release cycle time
40% by containerizing AI microservices with Docker and Kubernetes.
```

---

## 3. Neon IT Systems — ML Engineer

| Field | Value |
|---|---|
| Job title | ML Engineer |
| Company | Neon IT Systems |
| Location | India |
| From | January 2020 |
| To | December 2022 |

**Description**

```
Developed deep learning models (CNN, RNN, LSTM) for document classification,
invoice parsing and OCR-based extraction using OpenCV and TensorFlow,
reducing manual processing by 60%. Designed distributed Hadoop and Spark
pipelines to process multi-terabyte enterprise datasets. Migrated on-premises
ML workflows to AWS and Azure using S3, EC2 and SageMaker for distributed
training and real-time inference. Built hybrid SQL/NoSQL solutions for
semantic search and vector indexing, and maintained MLOps workflows covering
model versioning, monitoring and retraining.
```

**Note on dates:** this overlaps your BTech, which ran to July 2022.
Recruiters do flag that. If there's a free-text box, one clause settles it —
e.g. "concurrent with undergraduate study" — rather than leaving them to
wonder.

---

## Certifications — exact values for the form

### AWS Certified Solutions Architect – Associate
| Field | Value |
|---|---|
| Issuing organization | Amazon Web Services (AWS) |
| Credential / validation number | `d413bc6b1575487c92e1acc60f3cd3e0` |
| Issue date | July 3, 2025 |
| Expiration date | July 3, 2028 |
| Verify at | https://aws.amazon.com/verification |

### Oracle Certified Professional: Java SE 21 Developer
| Field | Value |
|---|---|
| Issuing organization | Oracle |
| Credential number | `101948298JSE21OCP` |
| Issue date | July 9, 2025 |
| Expiration | Does not expire |

### NVIDIA — OpenUSD Crash Course: Build 3D Data Pipelines for Physical AI
| Field | Value |
|---|---|
| Issuing organization | NVIDIA |
| Credential ID | `3qx3wzf8RnStzlwM7sdV5A` |
| Issue date | March 15, 2026 |
| Expiration | Does not expire |
| Verify at | https://learn.nvidia.com/certificates?id=3qx3wzf8RnStzlwM7sdV5A |

**On the NVIDIA one:** it's a Certificate of Competency for a short course,
not a proctored certification like the other two. It's honest to list it —
just keep it under "Certifications / Courses" and don't let it sit above the
AWS and Oracle credentials, which carry far more weight with recruiters.

---

## Education

| Field | Value |
|---|---|
| School | Northeastern University |
| Degree | Master of Science |
| Field of study | Data Analytics |
| Location | Boston, MA |
| Graduated | December 2024 |

| Field | Value |
|---|---|
| School | Vellore Institute of Technology |
| Degree | Bachelor of Technology |
| Field of study | Electronics and Computer Engineering |
| Location | Tamil Nadu, India |
| Graduated | July 2022 |

---

## Work authorization — the questions that gate you

**"Are you legally authorized to work in the United States?"** → **Yes**

**"Will you now or in the future require sponsorship for employment visa
status?"** → **Yes**

Answering No to the second because you can work today is the common and
costly mistake — the question asks about the future, and a contradiction
found later in the process is far more damaging than an upfront Yes.

Free-text version if offered:
> Authorized to work in the US on F-1 STEM OPT through February 2028; able to
> start immediately with no sponsorship required today. Will require H-1B
> sponsorship before that authorization ends.

**Security clearance:** not eligible. Skip roles requiring clearance or ITAR
access.
